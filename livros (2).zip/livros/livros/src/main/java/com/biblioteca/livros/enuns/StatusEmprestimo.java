package com.biblioteca.livros.enuns;

public enum StatusEmprestimo {
	EMPRESTADO,
	DEVOLVIDO,
}
